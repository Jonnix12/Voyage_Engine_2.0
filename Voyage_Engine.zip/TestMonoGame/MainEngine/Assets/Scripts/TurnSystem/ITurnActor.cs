﻿namespace Voyage_Engine.Game_Engine.Objects.Scripts.TurnSystem;

public interface ITurnActor
{
    public bool IsCurrentTurn { get; set; }
}