﻿using Voyage_Engine.Game_Engine.GameObjectSystem;

namespace Voyage_Engine.Game_Engine.TileMap;

public class TileGameObject : GameObject
{
    public override void Start()
    {
        base.Start();
    }
}