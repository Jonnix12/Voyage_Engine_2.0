﻿namespace Voyage_Engine.Game_Engine.TileMap;



//public abstract class TileObject
//{
//   protected int xPosition;
//   protected int yPosition;

//   public abstract void MoveToTile(int x, int y);
//   public abstract void InteractWithTile(Tile tile);

//   public abstract void InteractWithTileObject(TileObject tileObject);
//}