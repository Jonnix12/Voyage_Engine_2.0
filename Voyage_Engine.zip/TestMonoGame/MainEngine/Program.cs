﻿using Voyage_Engine.Game_Engine.Engine;

var mainGameEngine = new MainGameEngine();